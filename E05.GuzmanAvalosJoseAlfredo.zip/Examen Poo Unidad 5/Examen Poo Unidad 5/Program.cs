﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen_Poo_Unidad_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instanciamos la clase principal con su metodo de Bienvenida
            Principal Pi = new Principal();
            Pi.Bienvenida();
        }
    }
}
