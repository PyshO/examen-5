﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Examen_Poo_Unidad_5
{
    class Principal
    {
        //Creamos el metodo de Bienvenida para iniciar con el programa
        public void Bienvenida()
        {
            Console.WriteLine("Bienvenido a tu lista de tareas");
            Console.ReadKey();
            Menu();
        }

        //Creamos el metodo de menu para correr el programa
        public void Menu()
        {
            //Creamos el menu de opciones
            Console.WriteLine("Bienvenido al Menu");
            Console.WriteLine("Opc1.- Ver tu Lista de Tareas");
            Console.WriteLine("Opc2.- Buscar Tarea");
            Console.WriteLine("Opc3.- Cambiar status");
            Console.WriteLine("Opc4.- Salir");

            //Creamos una variable para el switch
            string n = Console.ReadLine();

            //Creamos un switch para seleccionar la opcion deseada
            switch (n)
            {
                //LLamamos el metodo de Mostrar Tareas
                case "1":
                    MostrarTareas();
                    break;

                    //Llamamos el metodo de Buscar tarea y creamos una variable para su sobrecarga
                case "2":
                    Console.WriteLine("Escribir el id");
                    int nom = Convert.ToInt32(Console.ReadLine());
                    BuscarTarea(nom);
                    Console.ReadKey();
                    break;

                    //Llamamos el metodo modificar
                case "3":
                    Modificar();
                    break;
                case "4":
                    Environment.Exit(4);
                    break;
            }
        }

        //Creamos el metodo para mostrar tareas
        public void MostrarTareas()
        {
            //creamos una lista para crear la informacion de las tareas
            List<string> tareas = new List<string>();

            //creamos el metodo de using e instanciamos la clase StreamReader con la ruta del archivo
            using (StreamReader leer = new StreamReader(@"C:\Users\hp\Documents\Datos.txt"))
            {
                //Creamos un while para poder acceder a la ruta con base a leer
                //El endofstream se encarga de realizar de realizar la actividad siempre y cuando se diferente al metodo
                //Va leer hasta el ultimo elemento del archivo
                while (!leer.EndOfStream)
                {
                    string n = leer.ReadLine();

                    //lo agregamos a la lista de tareas
                    tareas.Add(n);
                }
            }

            //Creamos un foreach para darle lectura a la lista
            foreach (string a in tareas)
            {
                //Imprimimos la informacion de la lista
                Console.WriteLine(a);
            }
            Console.ReadKey();
            Console.Clear();
            Menu();
        }

        public Tarea BuscarTarea(int id)
        {
            //Creamos una variable que llamara al metodo obtenerPersona
            var tareas = ObtenerPersonas(id);
            //Hacemos la condicion para buscar el nombre
            var n = (from tarea in tareas
                     where tarea.Id == id
                     select tarea).First();
            return n;
        }

        public List<String> ObtenerLineas()
        {
            //Aqui creamos el try catch para que nos de seguimiento o un aviso al no escribir 
            //Bien el dato ingresado(un error)
            try
            {
                //Creamos la lista para obtener la informacion de las lineas del archivo
                List<String> lineas = new List<string>();

                //Creamos un array para obtener las lineas
                string[] info = null;

                //Aqui se busca el archivo
                if (File.Exists(@"C:\Users\hp\Documents\Datos.txt"))
                {
                    info = File.ReadAllLines(@"C:\Users\hp\Documents\Datos.txt");
                }

                //Creamos un foreach para darle lectura a la informacion del archivo(lista de lineas)
                foreach (string item in info)
                {
                    lineas.Add(item);
                }
                return lineas;
            }

            //Creamos el catch para el error
            catch (System.Exception)
            {
                Console.WriteLine("Numero ingresado incorrecto");
            }
            return null;
        }

        public List<Tarea> ObtenerPersonas(int id)
        {
            //creamos una variable que llamara al metodo ObtenerLineas
            var datos = ObtenerLineas();

            //Instanciamos la clase de tarea en una lista
            List<Tarea> personas = new List<Tarea>();

            //creamos un foreach para buscar los datos 
            foreach (string item in datos)
            {
                //se crea el separador
                string[] info = item.Split(',');
                //Se asignan las lineas en las variables de tarea
                Tarea Pe = new Tarea
                {
                    Id = int.Parse(info[0]),
                    Nombre = info[1],
                    Hora = info[2],
                    Fecha = info[3],
                    Status = info[4],
                };

                //Lo agregamos a la lista de personas
                personas.Add(Pe);

                //Creamos la condicion para comparar el id ingresado y si es asi imprimir los datos
                if (id == Pe.Id )
                {
                    Console.WriteLine(Pe.Id+","+Pe.Nombre+"," + Pe.Hora+"," + Pe.Fecha+"," + Pe.Status);
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                }
            }
            return personas;
        }

        public void Modificar()
        {
            //se usa streamreader para la busquedad de un registro y streamwriter para escribir en un registro
            StreamReader lectura;
            StreamWriter escritura;

            //Creamos 4 variables
            //cadena sirve para ir leeyendo las lineas del archivo
            //tarea es para buscar el nombre de la tarea
            //Nuevo status es la variable que remplazara a la variable de status de la clase Tarea
            string cadena, tarea, nuevoStatus, respuesta;

            //Declaramos una variable y la inicializamos en false
            bool encontrado;
            encontrado = false;

            //Creamos un array para separar las lineas en las lineas
            //Creamos el separador
            string[] campos = new string[4];
            char[] separador = {','};

            //Creamos el try catch
            try
            {
                //aqui abrimos el archivo donde se encuentran las tareas
                //creamos nuevo archivo txt donde se ira ir guardando el respaldo de datos.txt
                lectura = File.OpenText(@"C:\Users\hp\Documents\Datos.txt");
                escritura = File.CreateText(@"C:\Users\hp\Documents\Remp.txt");

                //Aqui buscamos la tarea que deseamos modificar
                Console.WriteLine("Ingrese la tarea a modificar");
                tarea = Console.ReadLine();

                //aqui hacemos una lectura para recorrer el archivo y asi buscar los datos del archivo
                cadena = lectura.ReadLine();

                //Creamos una condicion que dice, su cadena es diferente a null quiere decir que el archivo tiene registros
                while (cadena != null)
                {
                    //en campos va almacenar lo que tiene cadena y lo separamos
                    campos = cadena.Split(separador);

                    //hacemos la condicion donde llamamos el primer indice en este caso nombre y con el trim quitamos los espacios
                    //el Equals es para comparar el indice con el nombre de la tarea
                    if (campos[1].Trim().Equals(tarea))
                    {
                        //si encontrado es verdadero entonces va imprimir la tarea y va pedir cambiar el status
                        encontrado = true;
                        Console.WriteLine(campos[0] +"," + campos[1] + campos[2] + campos[3] + campos[4]);
                        Console.WriteLine("________________________________________");

                        //Hacemos una condicion si es que muestra la tarea correcta
                        Console.WriteLine("Es la tarea que deseabas?");
                        respuesta = Console.ReadLine();

                        //Si la respuesta es si se cumple la siguiente condicion donde ingresaremos el nuevo status
                        if(respuesta=="si")
                        {
                            //Pedimos ingresar el nuevo status
                            Console.WriteLine("Ingresa el nuevo status");
                            nuevoStatus = Console.ReadLine();

                            //aqui vamos a modificar la tarea
                            escritura.WriteLine(campos[0] + campos[1] + campos[2] + campos[3] + "," + nuevoStatus);
                            Console.WriteLine("Cambio de status exitoso");
                        }
                        
                    }

                    //Si no es la tarea deseada hacemos de nuevo una lectura (esto es por si la tarea de repite)
                    else
                    {
                        escritura.WriteLine(cadena);
                    }
                    cadena = lectura.ReadLine();
                }

                //Si la tarea no se encuentra entonces va a mostrar que la tarea no se encuentra
                if (encontrado == false)
                {
                    Console.WriteLine("Esta tarea no se encuentra");
                }
                //Terminamos la operacion de buscar leer y escribir en el registro
                lectura.Close();
                escritura.Close();

                //Aqui hacemos la condicion donde el archivo de remp se va a guardar como el archivo de datos
                File.Delete(@"C:\Users\hp\Documents\Datos.txt");
                File.Move(@"C:\Users\hp\Documents\Remp.txt", @"C:\Users\hp\Documents\Datos.txt");
            }

            //Creamos el catch para que nos muestre el error
            catch(Exception e)
            {
                Console.WriteLine("Error" + e.Message);
            }
            Console.ReadKey();
            Console.Clear();
            Menu();
        }
    }
}

