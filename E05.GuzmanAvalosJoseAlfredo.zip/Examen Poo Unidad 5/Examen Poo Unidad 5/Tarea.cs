﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen_Poo_Unidad_5
{
    public class Tarea
    {
        //Creamos las variables y las encapsulamos
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Hora { get; set; }
        public string Fecha { get; set; }
        public string Status { get; set; }
    }
}
